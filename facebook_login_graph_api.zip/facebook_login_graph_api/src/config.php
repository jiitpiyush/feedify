<?php
$config['callback_url']         =   'http://feedify.co.in/facebook_login_graph_api/?fbTrue=true'; //   /?fbTrue=true allow you to code process section.

//Facebook configuration
$config['App_ID']      =   '890339714389290';
$config['App_Secret']  =   '966625d7185d3d258d1b58cf274724f8'; 

?>
