<?php 
	header('Location: /account/');
?>