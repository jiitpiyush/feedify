<?php
        include "check.php";
        $user = check(strtolower($_POST['user']));
        $options = ['cost' => 12,];
        $pass = md5($_POST['pass']);
        
        $user1=$_COOKIE['user'];
        $pass1=$_COOKIE['pass'];

        //$rdir = $_GET['next'];
        $rdir = $_SERVER['HTTP_REFERER'];

        if($user1 && $pass1)
        {
        	header('Location: /read.php');
        }
        else
        {
           include "../file.php";
           if($con->connect_error)
            {
        	   die('Connection Failed');
            }


           $sql = "SELECT * FROM fd_users where username='$user' AND pass='$pass'";
           $result = $con->query($sql);
          if ($result->num_rows > 0) 
           {
               setcookie("user", $user,time()+3600*24*30,"/",".feedify.co.in",false,1);
               setcookie("pass",$pass,time()+3600*24*30,"/",".feedify.co.in",false,1);
               $con->close();
                if($rdir)
                 {
            	   header("Location: $rdir");
                 }
                else
                {
                    header('Location: /read.php');
                }
            }
            else
            {
                header("Location: /?login_attempt=1&&user=$user");
            }
        }
?>